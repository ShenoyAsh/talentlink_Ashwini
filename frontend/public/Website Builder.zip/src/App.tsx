import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { StudentDashboard } from './components/StudentDashboard';
import { InstructorDashboard } from './components/InstructorDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { CourseViewer } from './components/CourseViewer';
import { GraduationCap, BookOpen, Shield, User } from 'lucide-react';
import { Card } from './components/ui/card';

export default function App() {
  const [userRole, setUserRole] = useState<'student' | 'instructor' | 'admin'>('student');
  const [activeCourse, setActiveCourse] = useState<string | null>(null);

  if (activeCourse && userRole === 'student') {
    return (
      <CourseViewer 
        courseId={activeCourse} 
        onBack={() => setActiveCourse(null)} 
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-br from-indigo-600 to-purple-600 p-2 rounded-lg">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-gray-900">LearnHub Pro</h1>
                <p className="text-sm text-gray-600">Adaptive Learning Platform</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <User className="w-5 h-5 text-gray-600" />
              <span className="text-sm text-gray-700">
                {userRole === 'student' ? 'Sarah Johnson' : userRole === 'instructor' ? 'Dr. James Miller' : 'Admin User'}
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Role Switcher */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Card className="p-4 bg-white">
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-600">Demo Mode: Switch between user roles</p>
            <div className="flex gap-2">
              <button
                onClick={() => setUserRole('student')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                  userRole === 'student'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <BookOpen className="w-4 h-4" />
                Student
              </button>
              <button
                onClick={() => setUserRole('instructor')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                  userRole === 'instructor'
                    ? 'bg-purple-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <GraduationCap className="w-4 h-4" />
                Instructor
              </button>
              <button
                onClick={() => setUserRole('admin')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                  userRole === 'admin'
                    ? 'bg-pink-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <Shield className="w-4 h-4" />
                Admin
              </button>
            </div>
          </div>
        </Card>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        {userRole === 'student' && (
          <StudentDashboard onEnrollCourse={setActiveCourse} />
        )}
        {userRole === 'instructor' && <InstructorDashboard />}
        {userRole === 'admin' && <AdminDashboard />}
      </main>
    </div>
  );
}
